# A Simple Diffusion Transformer on Unified Video, 3D, and Game Field Generation

This is a game generation demo with our DiFT. Its running requies at least 12 Gib GPU memory.

## Setup

To set up a Python virtual environment with the required dependencies, run:
```shell
# create virtual environment
python3 -m venv ./envs
source ./envs/bin/activate
# update pip, setuptools and wheel
pip3 install --upgrade pip setuptools wheel
# install all required packages
pip install omegaconf diffusers["torch"] transformers timm av gradio
```

Once done with virtual environment, deactivate with command:
```shell
deactivate
```
then delete venv with command:
```shell
rm -r ./envs
```

## Gradio Demo

Launch the gradio game generation demo in `super_mario_bros_1_1`.
![](imgs/gradio.png)